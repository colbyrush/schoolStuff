#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv)
{
  int x, y = 0;
  while (x == 0)
    {
      y++;
    }
}
